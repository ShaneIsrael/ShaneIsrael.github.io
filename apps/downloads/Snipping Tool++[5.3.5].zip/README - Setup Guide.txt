Version: 5.3.0

Snipping Tool++ Setup Guide
===========================

1) Be sure you have the latest Java installed
2) Windows: Double Click the Snipping Tool++.exe file located in the windows folder
   Mac: Double Click the Snipping Tool++.jar file located in the mac folder
* The program runs in the task tray (bottom right of your screen)
3) Right-click the programs icon in the task tray
4) Select Preferences
5) View the controls tab

Note: Snipping Tool++ does not automatically run when you start
windows. If you would like the program to automatically run whenever
you log into windows, put the "Snipping Tool++" file into your
windows startup folder. Located at "C:\Users\YOUR USERNAME GOES HERE\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"

Enjoy! Please feel free to donate on our website if you would like
to support the continued developement of this tool. http://www.snippingtoolplusplus.co.nf
------

Hint: Double click the program icon in the task tray
to open the programs save directory.

===================
UPDATE LOG [5.0.1]
=========

updates
=========
*Editor now properly resizes
*Editor preview color now correctly shows transparency level

bug fixes
=========
*fixed a bug that would cause adding text would not appear on the final edit
*fixed a bug where a small rectangle would appear on the final image
*fixed a bug that caused the transparency slider to always reset

===================
UPDATE LOG [5.0.4]
=========

updates
=========
*Redesign changes to Editor
*Submit directly to Reddit function (Press F10 when in the Editor)

=========
bug fixes
=========
*Changing a new color with the color preview was not setting the
selected transparency. 

===================
UPDATE LOG [5.0.5]
=========

bug fixes
=========
*Major uploading bug found and fixed. Sometimes uploading
would upload a previos snippet rather than a newly created one.

===================
UPDATE LOG [5.0.6]
=========

bug fixes
=========
*Minor bug fixes

===================
UPDATE LOG [5.1.0]
=========

Updates
========
*Now runs on Mac OS
*Added the Pastebin uploading feature (You can no longer log into an account like you could in older versions)
*Now using a .exe wrapper for windows users

Bug Fixes
=========
*Fixed a bug with sending images to the editor from the capture viewer
*Other minor fixes

===================
UPDATE LOG [5.1.1]
=========

Bug Fixes
=========
* Fixed a few bugs with the Mac version. Nothing serious.

===================
UPDATE LOG [5.2.0]
=========

Updates
=========
* A 'ding' sound is now played when an upload is finished
* New notification messages (a bit finicky on the mac side, still working on it)
* Now uses Java 1.6 instead of previously using Java 1.7

Bug Fixes
=========
* Fixed a few bugs on the Mac client, snipping should work correctly now

Known Bugs
==========
* Mac: When opening the popup menu, the menu sometimes opens on the left side of the screen, this is currently being looked into.

===================
UPDATE LOG [5.2.1]
=========

Updates
=========
* The application now checks for new updates to the program and notifies the user
* More modifications to the new notification system

Bug Fixes
=========
* 'ding' now correctly plays when an upload finishes

===================
UPDATE LOG [5.2.2]
=========

Bug Fixes
=========
* No longer submits multiple uploads at a time when using the submit hotkey within the editor.
* When using the text typing tool, text no longer disappears when you change the tool.
* Changing the color now correctly sets the transparency slider.

===================
UPDATE LOG [5.3.0]
=========

Updates
=========
* Added straight line tool.
* Changed the blur tools icon
* You can now change the border color
* You can now change the stroke size for editing tools

Bug Fixes
=========
* Program was not clearing up unused memory nicely, which would result
in huge memory consumption. This should no longer be an issue.
* Notifications do not move extremely slow across the screen when another
snipping tool++ utility/window is open.