from graphics import *
from button import Button
from tick import Tick

def main():
    win = GraphWin("Nao Control Window", 600,600)
    win.setCoords(0, 0, 600, 600)
    win.setBackground("black")

    tic = Tick(win, Point(300,300), 5)  #the window, middle, size of drawing
    
    kickButt = Button(win, Point(200, 550), 200, 50, "Kick")
    quitButt = Button(win, Point(200, 490), 200, 50, "quit") 
    kickButt.activate()
    quitButt.activate()

    running = 1 #1 true 0 false
    pt = win.getMouse()
    while running == 1:
        if kickButt.clicked(pt):
            kick()
        elif quitButt.clicked(pt):
        	running = 0 #exit the loop and kill the program
        pt = win.getMouse()

    win.close()

def kick():
	print "Kick!"
main()